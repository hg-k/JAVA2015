package Control;


import Entity.CGangjwa;

public class CGangjwaControl {

	public CGangjwa processGangjwa(CGangjwa gangjwa) {
	
		return gangjwa;
	}

}
