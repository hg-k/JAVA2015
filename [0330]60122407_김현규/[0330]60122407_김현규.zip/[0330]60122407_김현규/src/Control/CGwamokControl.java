package Control;

import Entity.CGwamok;

public class CGwamokControl {

	public CGwamok processGwamok(CGwamok gwamok) {
	
		return gwamok;
	}
}
