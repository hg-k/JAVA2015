package View;

import Entity.CGwamok;

public class CGwamokView {

	public CGwamok getGwamok() {
		
		// TODO Auto-generated method stub
		CGwamok gwamok = new CGwamok();
		gwamok.setID(21);
		gwamok.setName("�ڹ�");
		gwamok.setHakjeom(3);
				
		return gwamok;
	}

}
