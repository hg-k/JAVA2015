package View;

import Entity.CGangjwa;

public class CGangjwaView {

		public CGangjwa getGangjwa(){
			CGangjwa gangjwa = new CGangjwa();
			gangjwa.setID(50);
			gangjwa.setName("A��");
			gangjwa.setGwamokID(21);
			gangjwa.setTimes("1500");
			gangjwa.setGyosuID(100);
			gangjwa.setSuganginwon(55);
			
			
			return gangjwa;
		}
				
	}
